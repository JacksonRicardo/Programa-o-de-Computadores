import openai

# Load your API key from an environment variable or secret management service
openai.api_key = "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"
model_engine="text-davinci-003"
prompt= "Fazer uma API de consumo de CEP"

response= openai.Completion.create(
    engine=model_engine,
    prompt=prompt,
    max_tokens=2048,
    n=3,
    stop=['---'],
    temperature=0.9,
)

for result in response.choices:
    print(result.text)

